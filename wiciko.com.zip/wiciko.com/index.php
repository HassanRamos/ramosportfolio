<!DOCTYPE html>
<html lang="zxx">  
    
<head>
        <!-- meta tag -->
        <meta charset="utf-8">
        <title>Wiciko Ic - IT Solutions and Technology Company In Kenya</title>
        <meta name="description" content="">
        <!-- responsive tag -->
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- favicon -->
        <link rel="apple-touch-icon" href="apple-touch-icon.html">
        <link rel="shortcut icon" type="image/x-icon" href="assets/icon.png">
        <!-- Bootstrap v4.4.1 css -->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <!-- font-awesome css -->
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
        <!-- flaticon css -->
        <link rel="stylesheet" type="text/css" href="assets/fonts/flaticon.css">
        <!-- animate css -->
        <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
        <!-- owl.carousel css -->
        <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">
        <!-- slick css -->
        <link rel="stylesheet" type="text/css" href="assets/css/slick.css">
        <!-- off canvas css -->
        <link rel="stylesheet" type="text/css" href="assets/css/off-canvas.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
        <!-- Main Menu css -->
        <link rel="stylesheet" href="assets/css/rsmenu-main.css">
        <!-- spacing css -->
        <link rel="stylesheet" type="text/css" href="assets/css/rs-spacing.css">
        <!-- style css -->
        <link rel="stylesheet" type="text/css" href="style.css"> <!-- This stylesheet dynamically changed from style.less -->
        <!-- responsive css -->
        <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!--  ===================================================================================================================================================== -->

    <!-- Style of the plugin -->
    <link rel="stylesheet" href="plugin/whatsapp-chat-support.css">
    <link rel="stylesheet" href="plugin/components/Font Awesome/css/font-awesome.min.css">
    
    
 <!-- Pixel Code for https://getpopup.co/ -->
<script defer src="https://getpopup.co/pixel/kj5i6aaah91ewrfhowz9edkfmd0xjodb"></script>
<!-- END Pixel Code -->


    <!--  ===================================================================================================================================================== -->

    </head>
    <body class="defult-home">
        
        <!--Preloader area start here-->
        <div id="loader" class="loader">
            <div class="loader-container"></div>
        </div>
        <!--Preloader area End here--> 
     
    <!-- Main content Start -->
        <div class="main-content">
            
            <!--Full width header Start-->
            <div class="full-width-header">
                <!--Header Start-->
                <header id="rs-header" class="rs-header style3 header-transparent">
                    <!-- Topbar Area Start -->
                    <div class="topbar-area style2 modify1">
                       <div class="container">
                           <div class="row y-middle">
                               <div class="col-lg-8">
                                   <div class="topbar-contact">
                                      <ul>
                                          <li>
                                              <i class="flaticon-email"></i>
                                              <a href="mailto:info@wiciko.com">info@wiciko.com</a>
                                          </li>
                                          <li>
                                              <i class="flaticon-call"></i>
                                              <a href="tel:+254727527561">(+254)727527561</a>
                                          </li>
                                          <li>
                                              <i class="flaticon-location"></i>
                                              Mombasa
                                          </li>
                                      </ul>
                                   </div>
                               </div>
                               <div class="col-lg-4 text-right">
                                   <div class="toolbar-sl-share">
                                       <ul>
                                            <li class="opening"> <em><i class="flaticon-clock"></i> 08:00am-6:00pm</em> </li>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                       </ul>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                    <!-- Topbar Area End -->
                    
                    <!-- Menu Start -->
                    <div class="menu-area menu-sticky">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-3">
                                    <div class="logo-part">
                                        <a href="#">
                                            <img class="normal-logo" src="assets/wiciko.png" alt="logo">  
                                            <img class="sticky-logo" src="assets/wiciko.png" alt="logo">
                                        </a>
                                    </div>
                                    <div class="mobile-menu">
                                        <a href="#" class="rs-menu-toggle rs-menu-toggle-close">
                                            <i class="fa fa-bars"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-9 text-right">
                                    <div class="rs-menu-area">
                                        <div class="main-menu">
                                            <nav class="rs-menu pr-70 md-pr-0">
                                                <ul id="onepage-menu" class="nav-menu">
                                                    <li> <a href="#rs-header">Home</a></li>
                                                    <li><a href="#rs-about">About</a></li>
                                                    <li><a href="#rs-services">Services</a></li>
                                                    <li><a href="#rs-portfolio">Portfolio</a></li>
                                                    <!--<li><a href="#rs-team">Team</a></li>-->
                                                    <li><a href="#rs-contact">Contact</a></li>
                                                </ul> <!-- //.nav-menu -->
                                            </nav>                                        
                                        </div> <!-- //.main-menu -->
                                                                   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Menu End --> 
                </header>
                <!--Header End-->
                <!-- Canvas Menu start -->
                <nav class="right_menu_togle hidden-md">
                    <div class="close-btn"><span id="nav-close" class="text-center"><i class="fa fa-close"></i></span></div>
                    <div class="canvas-logo">
                        <a href="#"><img src="assets/images/logo-dark.png" alt="logo"></a>
                    </div>
                    <div class="offcanvas-text">
                        <p>.</p>
                    </div>
                    <div class="canvas-contact">
                        <h5 class="canvas-contact-title">Contact Info</h5>
                        <ul class="contact">
                            <li><i class="fa fa-globe"></i>Mombasa</li>
                            <li><i class="fa fa-phone"></i>(+254)727527561</li>
                            <li><i class="fa fa-envelope"></i><a href="mailto:info@wiciko.com">info@wiciko.com</a></li>
                            <li><i class="fa fa-clock-o"></i>08:00 AM - 18:00 PM</li>
                        </ul>
                        <ul class="social">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </nav>
                <!-- Canvas Menu end -->
            </div>
            <!--Full width header End-->
         
            <!-- Banner Section Start -->
            <div class="rs-banner style2 pt-120 pb-120 md-pt-0 md-pb-0">
                <div class="container">
                    <div class="banner-content">
                       <div class="sub-title wow bounceInLeft" data-wow-delay="300ms" data-wow-duration="2000ms">It Software & Design</div>
                       <h1 class="title wow fadeInRight" data-wow-delay="600ms" data-wow-duration="2000ms"> Leading It & Software</h1>
                        <h2 class=" title-small wow fadeInUp" data-wow-delay="900ms" data-wow-duration="2000ms">
                            Development Company
                        </h2> 
                        
                    </div>
                </div>
            </div>
            <!-- Banner Section End -->
      
            <!-- Services Section Start -->
            <div class="rs-services main-home style2 pt-120 pb-120 md-pt-80 md-pb-80">
                <div class="container">
                    <div class="sec-title2 text-center mb-45">
                        
                        <h2 class="title title2">
                           Our
                        </h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 md-mb-30">
                           <div class="services-item">
                               <div class="services-icon">
                                   <div class="image-part">
                                       <img src="assets/images/services/style1/1.png" alt="">                                      
                                   </div>
                               </div>
                               <div class="shape-part">
                                   <img class="move-y" src="assets/images/services/shape.png" alt="">
                               </div>
                               <div class="services-content">
                                   <div class="services-text">
                                       <h3 class="services-title"><a href="#">Mission</a></h3>
                                   </div>
                                   <div class="services-desc">
                                       <p>
                                         Build excellent software that improves the lives of humanity
                                       </p>
                                   </div>
                               </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-4 md-mb-30">
                           <div class="services-item active">
                               <div class="services-icon">
                                   <div class="image-part">
                                       <img src="assets/images/services/style1/2.png" alt="">  
                                   </div>
                               </div>
                               <div class="shape-part">
                                   <img class="move-y" src="assets/images/services/shape.png" alt="">
                               </div>
                               <div class="services-content">
                                   <div class="services-text">
                                       <h3 class="services-title"><a href="#">Vission</a></h3>
                                   </div>
                                   <div class="services-desc">
                                       <p>
                                        A better world with life full of Simplicity.
                                       </p>
                                   </div>
                               </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-4">
                           <div class="services-item">
                               <div class="services-icon">
                                   <div class="image-part">
                                       <img src="assets/images/services/style1/3.png" alt="">  
                                   </div>
                               </div>
                               <div class="shape-part">
                                   <img class="move-y" src="assets/images/services/shape.png" alt="">
                               </div>
                               <div class="services-content">
                                   <div class="services-text">
                                       <h3 class="services-title"><a href="#">Motto</a></h3>
                                   </div>
                                   <div class="services-desc">
                                       <p>
                                            Best Tech, Best Future.
                                       </p>
                                   </div>
                               </div>
                           </div> 
                        </div>
                    </div>
                </div>
            </div>
            <!-- Services Section End -->

            <!-- About Section Start -->
            <div id="rs-about" class="rs-about gray-color pt-120 pb-120 md-pt-80 md-pb-80">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 md-mb-30">
                            <div class="rs-animation-shape">
                                <div class="images">
                                   <img src="assets/images/about/about-3.png" alt=""> 
                                </div>
                                <div class="middle-image2">
                                   <img class="dance" src="assets/images/about/effect-1.png" alt=""> 
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 pl-60 md-pl-15">
                            <div class="contact-wrap">
                                <div class="sec-title mb-30">
                                    <div class="sub-text style-bg">About Us</div>
                                    <h2 class="title pb-38">
                                        We Are Increasing Business Success With Technology
                                    </h2>
                                    <div class="desc pb-35">
                                       Over 6 years working in IT services developing software applications and mobile apps for clients all over the world.
                                    </div>
                                    <p class="margin-0 pb-15">
                                      
                                    </p>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="shape-image">
                        <img class="top dance" src="assets/images/about/dotted-3.png" alt="">
                        <img class="bottom dance" src="assets/images/about/shape3.png" alt="">
                    </div>
                </div>
            </div>
            <!-- About Section End -->

            <!-- Services Section Start -->
            <div id="rs-services" class="rs-services style2 pt-120 pb-120 md-pt-80 md-pb-80">
                <div class="container">
                    <div class="sec-title2 text-center mb-45">
                        <span class="sub-text style-bg">Services</span>
                        <h2 class="title">
                           We Are Offering All Kinds of IT Solutions Services
                        </h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6 mb-25">
                           <div class="flip-box-inner">
                                <div class="flip-box-wrap">
                                    <div class="front-part">
                                       <div class="front-content-part">
                                            <div class="front-icon-part">
                                                <div class="icon-part">
                                                    <img src="assets/images/services/main-home/icons/1.png" alt=""> 
                                                </div>
                                            </div>
                                            <div class="front-title-part">
                                                <h3 class="title"><a href="#">Software Development</a></h3>
                                            </div>
                                            <div class="front-desc-part">
                                                <p>
                                                    Mobile apps CRM,ERP and Desktop
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="back-front">
                                        <div class="back-front-content">
                                            <div class="back-title-part">
                                                <h3 class="back-title"><a href="#">Software Development</a></h3>
                                            </div>
                                            <div class="back-desc-part">
                                                <p class="back-desc"> Mobile apps CRM,ERP and Desktop</p>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-6 mb-25">
                           <div class="flip-box-inner">
                                <div class="flip-box-wrap">
                                    <div class="front-part">
                                       <div class="front-content-part">
                                            <div class="front-icon-part">
                                                <div class="icon-part">
                                                    <img src="assets/images/services/main-home/icons/2.png" alt=""> 
                                                </div>
                                            </div>
                                            <div class="front-title-part">
                                                <h3 class="title"><a href="#"> Web Development</a></h3>
                                            </div>
                                            <div class="front-desc-part">
                                                <p>
                                                    Websites and Web softwares(Ecommerce,blogs)
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="back-front">
                                        <div class="back-front-content">
                                            <div class="back-title-part">
                                                <h3 class="back-title"><a href="#"> Web Development</a></h3>
                                            </div>
                                            <div class="back-desc-part">
                                                <p class="back-desc">Websites and Web softwares(Ecommerce,blogs)</p>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-6 mb-25">
                           <div class="flip-box-inner">
                                <div class="flip-box-wrap">
                                    <div class="front-part">
                                       <div class="front-content-part">
                                            <div class="front-icon-part">
                                                <div class="icon-part">
                                                    <img src="assets/images/services/main-home/icons/3.png" alt=""> 
                                                </div>
                                            </div>
                                            <div class="front-title-part">
                                                <h3 class="title"><a href="#">Analytic Solutions</a></h3>
                                            </div>
                                            <div class="front-desc-part">
                                                <p>
                                                    Data Aalysis using R ad Python.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="back-front">
                                        <div class="back-front-content">
                                            <div class="back-title-part">
                                                <h3 class="back-title"><a href="#">Analytic Solutions</a></h3>
                                            </div>
                                            <div class="back-desc-part">
                                                <p class="back-desc">Data Aalysis using R ad Python.</p>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-6 md-mb-25">
                           <div class="flip-box-inner">
                                <div class="flip-box-wrap">
                                    <div class="front-part">
                                       <div class="front-content-part">
                                            <div class="front-icon-part">
                                                <div class="icon-part">
                                                    <img src="assets/images/services/main-home/icons/4.png" alt=""> 
                                                </div>
                                            </div>
                                            <div class="front-title-part">
                                                <h3 class="title"><a href="#">Cloud and DevOps</a></h3>
                                            </div>
                                            <div class="front-desc-part">
                                                <p>
                                                    creates an agile process for the rapid delivery of reliable services
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="back-front">
                                        <div class="back-front-content">
                                            <div class="back-title-part">
                                                <h3 class="back-title"><a href="#">Cloud and DevOps</a></h3>
                                            </div>
                                            <div class="back-desc-part">
                                                <p class="back-desc">creates an agile process for the rapid delivery of reliable services</p>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-6 sm-mb-25">
                           <div class="flip-box-inner">
                                <div class="flip-box-wrap">
                                    <div class="front-part">
                                       <div class="front-content-part">
                                            <div class="front-icon-part">
                                                <div class="icon-part">
                                                    <img src="assets/images/services/main-home/icons/5.png" alt=""> 
                                                </div>
                                            </div>
                                            <div class="front-title-part">
                                                <h3 class="title"><a href="#">Product Design</a></h3>
                                            </div>
                                            <div class="front-desc-part">
                                                <p>
                                                    Web app  and mobile app design, Logo,posters,Business cards
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="back-front">
                                        <div class="back-front-content">
                                            <div class="back-title-part">
                                                <h3 class="back-title"><a href="#">Product Design</a></h3>
                                            </div>
                                            <div class="back-desc-part">
                                                <p class="back-desc">Web app  and mobile app design, Logo,posters,Business cards</p>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                           </div> 
                        </div>
                        <div class="col-lg-4 col-md-6">
                           <div class="flip-box-inner">
                                <div class="flip-box-wrap">
                                    <div class="front-part">
                                       <div class="front-content-part">
                                            <div class="front-icon-part">
                                                <div class="icon-part">
                                                    <img src="assets/images/services/main-home/icons/6.png" alt=""> 
                                                </div>
                                            </div>
                                            <div class="front-title-part">
                                                <h3 class="title"><a href="#">Database Administration</a></h3>
                                            </div>
                                            <div class="front-desc-part">
                                                <p>
                                                    database design and much of database implementation,use software to store and organize data
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="back-front">
                                        <div class="back-front-content">
                                            <div class="back-title-part">
                                                <h3 class="back-title"><a href="#">Database Administration</h3>
                                            </div>
                                            <div class="back-desc-part">
                                                <p class="back-desc">database design and much of database implementation,use software to store and organize data</p>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                           </div> 
                        </div>
                    </div>
                </div>
                <div class="shape-animation">
                    <div class="shape-part">
                        <img class="dance" src="assets/images/services/s2.png" alt="images">
                    </div>
                </div>
            </div>
            <!-- Services Section End -->
         
           
            
            <!-- Project Section Start -->
            <div id="rs-portfolio" class="rs-project bg6 style2 pt-120 pb-120 md-pt-80 md-pb-80">
                <div class="container">
                    <div class="sec-title2 text-center mb-45">
                        <span class="sub-text style-bg white-color">Products</span>
                        <h2 class="title title2 white-color">
                           Some of Our Products
                        </h2>
                    </div>
                    <div class="rs-carousel owl-carousel" data-loop="true" data-items="3" data-margin="30" data-autoplay="true" data-hoverpause="true" data-autoplay-timeout="5000" data-smart-speed="800" data-dots="false" data-nav="false" data-nav-speed="false" data-center-mode="false" data-mobile-device="1" data-mobile-device-nav="false" data-mobile-device-dots="false" data-ipad-device="2" data-ipad-device-nav="false" data-ipad-device-dots="false" data-ipad-device2="2" data-ipad-device-nav2="false" data-ipad-device-dots2="false" data-md-device="3" data-md-device-nav="true" data-md-device-dots="false">
                        <div class="project-item">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project/main-home/studialb.png" alt="images"></a>
                            </div>
                            <div class="project-content ">
                                <div class="vertical-middle">
                                    <div class="vertical-middle-cell">
                                        <h3 class="title"><a href="https://studialabs.co.ke/" target="_blank">Studialabs</a></h3>
                                        <span class="category"><a href="https://studialabs.co.ke/" target="_blank">Check it out</a></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="project-item">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project/main-home/shrill.png" alt="images"></a>
                            </div>
                            <div class="project-content ">
                                <div class="vertical-middle">
                                    <div class="vertical-middle-cell">
                                        <h3 class="title"><a href="http://Shrillonline.com" target="_blank">Shrillonline</a></h3>
                                        <span class="category"><a href="https://Shrillonline.com" target="_blank">chec it kout</a></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                           <div class="project-item">
                            <div class="project-img">
                                <a href="#"><img src="assets/images/project/main-home/onla.png" alt="images"></a>
                            </div>
                            <div class="project-content ">
                                <div class="vertical-middle">
                                    <div class="vertical-middle-cell">
                                        <h3 class="title"><a href="https://onla.cloud/" target="_blank">Onla Platform</a></h3>
                                        <span class="category"><a href="https://onla.cloud/" target="_blank">Chec it kout</a></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--  <div class="project-item">-->
                        <!--    <div class="project-img">-->
                        <!--        <a href="#"><img src="assets/images/project/main-home/popup.png" alt="images"></a>-->
                        <!--    </div>-->
                        <!--    <div class="project-content ">-->
                        <!--        <div class="vertical-middle">-->
                        <!--            <div class="vertical-middle-cell">-->
                        <!--                <h3 class="title"><a href="https://popup.onla.cloud/" target="_blank">Pop-Up</a></h3>-->
                        <!--                <span class="category"><a href="https://popup.onla.cloud/" target="_blank">chec it kout</a></span>-->
                        <!--            </div>-->
                        <!--        </div>-->
                        <!--    </div>-->
                        <!--</div>-->
                 
                    </div>
                </div>
            </div>
            <!-- Project Section End -->

            <!-- Contact Section Start -->
            <div id="rs-contact" class="rs-contact pt-120 gray-color">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4">
                           <div class="contact-box">
                                <div class="sec-title mb-45">
                                    <span class="sub-text new-text white-color">Let's Talk</span>
                                    <h2 class="title white-color">Have some query</h2>
                                </div>
                               <div class="address-box mb-25">
                                   <div class="address-icon">
                                       <i class="fa fa-home"></i>
                                   </div>
                                   <div class="address-text">
                                        <span class="label">Email:</span>
                                        <a href="tel:(">info@wiciko.com</a>
                                   </div>
                               </div>
                               <div class="address-box mb-25">
                                   <div class="address-icon">
                                       <i class="fa fa-phone"></i>
                                   </div>
                                   <div class="address-text">
                                       <span class="label">Phone:</span>
                                       <a href="#">(+254)727527561</a>
                                   </div>
                               </div>
                               <div class="address-box">
                                   <div class="address-icon">
                                       <i class="fa fa-map-marker"></i>
                                   </div>
                                   <div class="address-text">
                                       <span class="label">Address:</span>
                                       <div class="desc">Mombasa</div>
                                   </div>
                               </div>
                           </div>
                        </div> 
                        <div class="col-lg-8 pl-70 md-pl-15 md-mt-40">
                            <div class="contact-widget onepage-style">
                               <div class="sec-title2 mb-40">
                                   <span class="sub-text contact mb-15">Get In Touch</span>
                                   <h2 class="title testi-title">Fill The Form Below</h2>

                               </div>
                                <div id="form-messages"></div>
                                <form id="contact-form" method="post" action="https://wiciko.com/mail.php">
                                    <fieldset>
                                        <div class="row">
                                            <div class="col-lg-6 mb-30 col-md-6 col-sm-6">
                                                <input class="from-control" type="text" id="name" name="contact-name" placeholder="Name" required="">
                                            </div> 
                                            <div class="col-lg-6 mb-30 col-md-6 col-sm-6">
                                                <input class="from-control" type="text" id="email" name="contact-email" placeholder="E-Mail" required="">
                                            </div>   
                                            <div class="col-lg-6 mb-30 col-md-6 col-sm-6">
                                                <input class="from-control" type="text" id="phone" name="contact-phone" placeholder="Phone Number" required="">
                                            </div>   
                                            <div class="col-lg-6 mb-30 col-md-6 col-sm-6">
                                                <input class="from-control" type="text" id="Website" name="contact-company" placeholder="Your Company Name" required="">
                                            </div>
                                      
                                            <div class="col-lg-12 mb-30">
                                                <textarea class="from-control" id="message" name="contact-message" placeholder="Your message Here" required=""></textarea>
                                            </div>
                                        </div>
                                        <div class="btn-part">
                                            <div class="form-group mb-0">
                                                <input class="readon learn-more submit" type="submit" value="Submit Now">
                                            </div>
                                        </div> 
                                    </fieldset>
                                </form> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="map-canvas pt-120 md-pt-70">

                    <iframe width="1080" height="200" id="gmap_canvas" src="https://maps.google.com/maps?q=TUM%20Mombasa%20&t=k&z=9&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
            </div>
            <!-- Contact Section Start -->

            <!-- Cta section start -->
            <div class="rs-cta style1 bg7 pt-70 pb-70">
                <div class="container">
                    <div class="cta-wrap">
                        <div class="row align-items-center">
                            <div class="col-lg-9 col-md-12 md-pr-0 pr-148 md-pl-15 md-mb-30 md-center">
                                <div class="title-wrap">
                                    <h2 class="epx-title">Grow Your Business and Build Your Website or Software With us. Contact us</h2>
                                </div>
                            </div>
                            <
                        </div>
                    </div>
                </div>
            </div>
            <!-- Cta section end -->

        </div> 
        <!-- Main content End -->
              <!--
    /* ====================================================================== *
            EXAMPLE 2
     * ====================================================================== */
 -->    

    <div class="whatsapp_chat_support wcs_fixed_left" id="example_2">
        <div class="wcs_button wcs_button_circle">
            <span class="fa fa-whatsapp"></span>
        </div>  
        <div class="wcs_button_label">
            Questions? Let's Chat
        </div>  

        <div class="wcs_popup">
            <div class="wcs_popup_close">
                <span class="fa fa-close"></span>
            </div>
            <div class="wcs_popup_header">
                <span class="fa fa-whatsapp"></span>
                <strong>Customer Support</strong>
                
                <div class="wcs_popup_header_description">Have any query? Chat with us on Whatsapp</div>
            </div>  
            <div class="wcs_popup_input" data-number="2540727527561">
                <input type="text" placeholder="Ask anything!" />
                <i class="fa fa-play"></i>
            </div>
            <div class="wcs_popup_avatar">
                <img src="img/person_5.jpg" alt="">
            </div>
        </div>
    </div>  

<!--
    /* ====================================================================== *
            EXAMPLE 3
     * ====================================================================== */
 -->    
     
        <!-- Footer Start -->
        <footer id="rs-footer" class="rs-footer">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-12 col-sm-12 footer-widget">
                            <div class="footer-logo mb-30">
                                <a href="#"><img src="assets/wiciko.png" alt=""></a>
                            </div>
                              <div class="textwidget pb-30"><p>Sedut perspiciatis unde omnis iste natus error sitlutem acc usantium doloremque denounce with illo inventore veritatis</p>
                              </div>
                              <ul class="footer-social md-mb-30">  
                                  <li> 
                                      <a href="https://www.facebook.com/studialabs/" target="_blank"><span><i class="fa fa-facebook"></i></span></a> 
                                  </li>
                                  <li> 
                                      <a href="https://twitter.com/studialabs" target="_blank"><span><i class="fa fa-twitter"></i></span></a> 
                                  </li>

                                  <li> 
                                      <a href="https://ke.linkedin.com/company/studia-labs " target="_blank"><span><i class="fa fa-linkedin"></i></span></a> 
                                  </li>
                                  <li> 
                                      <a href="https://www.instagram.com/studialabs_ke/ " target="_blank"><span><i class="fa fa-instagram"></i></span></a> 
                                  </li>
                                                                           
                              </ul>
                        </div>
                        <div class="col-lg-3 col-md-12 col-sm-12 pl-45 md-pl-15 md-mb-30">
                            <h3 class="widget-title">IT Services</h3>
                            <ul class="site-map">
                                <li><a href="#">Software Development</a></li>
                                <li><a href="#">Web Development</a></li>
                                <li><a href="#">Analytic Solutions</a></li>
                                <li><a href="#">Cloud and DevOps</a></li>
                                <li><a href="#">Project Design</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-12 col-sm-12 md-mb-30">
                            <h3 class="widget-title">Contact Info</h3>
                            <ul class="address-widget">
                                <li>
                                    <i class="flaticon-location"></i>
                                    <div class="desc">Mombasa</div>
                                </li>
                                <li>
                                    <i class="flaticon-call"></i>
                                    <div class="desc">
                                       <a href="tel:(+254)727527561">(+254)727527561/(+254)768702038</a>
                                    </div>
                                </li>
                                <li>
                                    <i class="flaticon-email"></i>
                                    <div class="desc">
                                        <a href="mailto:info@wiciko.com">info@wiciko.com</a>
                                    </div>
                                </li>
                                <li>
                                    <i class="flaticon-clock-1"></i>
                                    <div class="desc">
                                        Opening Hours: 08:00 - 18:00   
                                    </div>
                                </li>
                            </ul>
                        </div>
                     
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">                    
                    <div class="row y-middle">
                        
                        <div class="col-lg-6">
                            <div class="copyright">
                                <p>&copy; 2021 Wiciko All Rights Reserved. Developed By <a href="http://studialabs.co.ke/" target="_blank">Studialabs</a></p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer End -->



        <!-- start scrollUp  -->
        <div id="scrollUp" class="orange-color">
            <i class="fa fa-angle-up"></i>
        </div>
        <!-- End scrollUp  -->

     
<!-- jQuery 1.8+ -->
    <script src="plugin/components/jQuery/jquery-1.11.3.min.js"></script>

    <!-- Plugin JS file -->
    <script src="plugin/components/moment/moment.min.js"></script>
    <script src="plugin/components/moment/moment-timezone-with-data.min.js"></script>
    <script src="plugin/whatsapp-chat-support.js"></script>

    <script>
        $('#example_1').whatsappChatSupport({
            debug: true,
        });

        $('#example_2').whatsappChatSupport({
            defaultMsg: '',
        });

        $('#example_3').whatsappChatSupport();
    </script>

         <!-- modernizr js -->
        <script src="assets/js/modernizr-2.8.3.min.js"></script>
        <!-- jquery latest version -->
        <script src="assets/js/jquery.min.js"></script>
        <!-- Bootstrap v4.4.1 js -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Menu js -->
        <script src="assets/js/rsmenu-main.js"></script> 
        <!-- op nav js -->
        <script src="assets/js/jquery.nav.js"></script>
        <!-- owl.carousel js -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- wow js -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Skill bar js -->
        <script src="assets/js/skill.bars.jquery.js"></script>
        <script src="assets/js/jquery.counterup.min.js"></script> 
         <!-- counter top js -->
        <script src="assets/js/waypoints.min.js"></script>
        <!-- swiper js -->
        <script src="assets/js/swiper.min.js"></script>   
        <!-- particles js -->
        <script src="assets/js/particles.min.js"></script>  
        <!-- magnific popup js -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>      
        <!-- plugins js -->
        <script src="assets/js/plugins.js"></script>
        <!-- pointer js -->
        <script src="assets/js/pointer.js"></script>
        <!-- contact form js -->
        <script src="assets/js/contact.form.js"></script>
        <!-- main js -->
        <script src="assets/js/main.js"></script>
    </body>

</html>